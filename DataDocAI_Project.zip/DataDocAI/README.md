# DataDocAI — Intelligent Data Quality & Error Detection System

DataDocAI is a small Python/Streamlit application for profiling tabular datasets and identifying common data-quality issues.

## Features
- Upload CSV and Excel files
- Preview the uploaded dataset
- Show row and column counts
- Calculate dataset completeness
- Detect missing values by column
- Detect duplicate rows
- Display column data types and distinct-value counts
- Flag constant columns
- Download a duplicate-free CSV and a column-level quality report

## Run locally

1. Install Python 3.10 or newer.
2. Open a terminal in this project folder.
3. Create and activate a virtual environment (recommended).
4. Install dependencies:

   ```bash
   pip install -r requirements.txt
   ```

5. Start the app:

   ```bash
   streamlit run app.py
   ```

6. Open the local URL shown in the terminal (usually http://localhost:8501).

## Project structure

```text
DataDocAI/
├── app.py
├── requirements.txt
└── README.md
```

## Important limitations
This starter version performs basic rule-based data-quality checks. It does not train or use an AI/ML model, connect to SQL Server, or automatically correct missing or invalid values. The duplicate-free download removes exact duplicate rows only. Validate outputs before relying on them.
