import streamlit as st
import pandas as pd
import numpy as np
from io import BytesIO

st.set_page_config(page_title="DataDocAI", page_icon="🔎", layout="wide")
st.title("🔎 DataDocAI")
st.caption("Intelligent Data Quality & Error Detection System")

uploaded = st.file_uploader("Upload a CSV or Excel dataset", type=["csv", "xlsx", "xls"])

def load_data(file):
    if file.name.lower().endswith(".csv"):
        return pd.read_csv(file)
    return pd.read_excel(file)

def analyze(df):
    report = []
    for col in df.columns:
        missing = int(df[col].isna().sum())
        duplicates = int(df.duplicated().sum())
        report.append({
            "Column": str(col),
            "Data Type": str(df[col].dtype),
            "Missing Values": missing,
            "Missing %": round(missing / max(len(df), 1) * 100, 2),
            "Unique Values": int(df[col].nunique(dropna=True)),
            "Constant Column": bool(df[col].nunique(dropna=True) <= 1)
        })
    duplicate_rows = int(df.duplicated().sum())
    return pd.DataFrame(report), duplicate_rows

if uploaded:
    try:
        df = load_data(uploaded)
        st.subheader("Dataset preview")
        st.dataframe(df.head(100), use_container_width=True)
        report, duplicate_rows = analyze(df)
        total_cells = df.shape[0] * df.shape[1]
        missing_cells = int(df.isna().sum().sum())
        completeness = 100 if total_cells == 0 else (1 - missing_cells / total_cells) * 100

        c1, c2, c3, c4 = st.columns(4)
        c1.metric("Rows", f"{df.shape[0]:,}")
        c2.metric("Columns", f"{df.shape[1]:,}")
        c3.metric("Duplicate rows", f"{duplicate_rows:,}")
        c4.metric("Completeness", f"{completeness:.1f}%")

        st.subheader("Column-level quality report")
        st.dataframe(report, use_container_width=True)

        st.subheader("Issues detected")
        issues = []
        for _, row in report.iterrows():
            if row["Missing Values"] > 0:
                issues.append(f"Column **{row['Column']}** contains {row['Missing Values']} missing value(s).")
            if row["Constant Column"]:
                issues.append(f"Column **{row['Column']}** has one or zero distinct non-null values.")
        if duplicate_rows:
            issues.append(f"The dataset contains **{duplicate_rows} duplicate row(s)**.")
        if issues:
            for issue in issues:
                st.warning(issue)
        else:
            st.success("No missing values, duplicate rows, or constant columns detected by the basic checks.")

        st.subheader("Download results")
        cleaned = df.drop_duplicates()
        csv_bytes = cleaned.to_csv(index=False).encode("utf-8")
        st.download_button("Download dataset without duplicate rows (CSV)", csv_bytes,
                           file_name="datadocai_cleaned.csv", mime="text/csv")
        report_bytes = report.to_csv(index=False).encode("utf-8")
        st.download_button("Download quality report (CSV)", report_bytes,
                           file_name="datadocai_quality_report.csv", mime="text/csv")
    except Exception as exc:
        st.error(f"Could not read or analyze this file: {exc}")
else:
    st.info("Upload a CSV or Excel file to begin the data quality analysis.")
    st.markdown("""
    **Current checks**
    - Missing-value counts and percentages
    - Duplicate-row detection
    - Column data types and unique-value counts
    - Constant-column detection
    - Dataset completeness score
    - Downloadable duplicate-free dataset and quality report

    This is a starter implementation. Review the results before using any cleaned data in production.
    """)
